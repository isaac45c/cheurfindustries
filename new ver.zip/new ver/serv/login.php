<?php
session_start();

$user_login_err = $user_password_err = $login_err = "";
$user_login = $user_password = "";

// Charger les utilisateurs depuis users.json
$users = json_decode(file_get_contents("users.json"), true);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_login = trim($_POST["user_login"]);
    $user_password = trim($_POST["user_password"]);

    if (empty($user_login)) {
        $user_login_err = "Please enter your username or email.";
    }
    if (empty($user_password)) {
        $user_password_err = "Please enter your password.";
    }

    if (empty($user_login_err) && empty($user_password_err)) {
        $found = false;
        foreach ($users as $user) {
            if (($user["username"] === $user_login || $user["email"] === $user_login) &&
                password_verify($user_password, $user["password"])) {
                $_SESSION["loggedin"] = true;
                $_SESSION["username"] = $user["username"];
                $_SESSION["role"] = $user["role"] ?? "user";
                header("Location: ../index.php");
                exit;
            }
        }
        $login_err = "Invalid username/email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Spinzone</title>
    <style>
        body {
            background: #121212;
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background: #1e1e1e;
            padding: 30px;
            border-radius: 12px;
            width: 300px;
            box-shadow: 0 0 10px rgba(0,0,0,0.5);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #0055ff;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: none;
            border-radius: 6px;
        }
        button {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background: #0055ff;
            border: none;
            border-radius: 6px;
            color: white;
            font-weight: bold;
        }
        .error { color: red; font-size: 0.9em; }
    </style>
</head>
<body>
    <form method="post">
        <h2>Login</h2>
        <input type="text" name="user_login" placeholder="Username or Email" value="<?= htmlspecialchars($user_login) ?>">
        <?php if ($user_login_err): ?><div class="error"><?= $user_login_err ?></div><?php endif; ?>

        <input type="password" name="user_password" placeholder="Password">
        <?php if ($user_password_err): ?><div class="error"><?= $user_password_err ?></div><?php endif; ?>

        <?php if ($login_err): ?><div class="error"><?= $login_err ?></div><?php endif; ?>

        <button type="submit">Login</button>
        <a href="./register.php" style="color:#00f;text-decoration:underline;">signin</a>
    </form>
</body>
</html>
