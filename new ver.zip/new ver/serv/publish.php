<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

function generateRandomString($length = 15) {
    return substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", 5)), 0, $length);
}

$uploadDir = __DIR__ . '/../cont/media/';
if (!file_exists($uploadDir)) mkdir($uploadDir, 0755, true);

$success = $error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $contentText = trim($_POST['content']);
    $file = $_FILES['media'];
    $randomName = generateRandomString();
    $timestamp = date("Y-m-d H:i:s");
    $username = $_SESSION['username'];

    $jsonData = [
        'id' => $randomName,
        'author' => $username,
        'date' => $timestamp,
        'content' => $contentText,
        'type' => '',
        'filename' => null
    ];

    if (!empty($file['name'])) {
        $fileType = mime_content_type($file['tmp_name']);
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $targetFile = $uploadDir . $randomName . "." . $extension;

        // Types autorisés
        $allowed = ['image/', 'video/', 'audio/'];
        $isAllowed = false;
        foreach ($allowed as $type) {
            if (strpos($fileType, $type) === 0) {
                $isAllowed = true;
                $jsonData['type'] = $type;
                break;
            }
        }

        if ($isAllowed) {
            if (move_uploaded_file($file['tmp_name'], $targetFile)) {
                $jsonData['filename'] = basename($targetFile);
                file_put_contents($uploadDir . $randomName . ".json", json_encode($jsonData, JSON_PRETTY_PRINT));
                $success = "Publication réussie avec le média.";
            } else {
                $error = "Échec du téléchargement.";
            }
        } else {
            $error = "Type de média non autorisé.";
        }
    } elseif (!empty($contentText)) {
        $jsonData['type'] = 'text';
        file_put_contents($uploadDir . $randomName . ".json", json_encode($jsonData, JSON_PRETTY_PRINT));
        $success = "Publication texte réussie.";
    } else {
        $error = "Veuillez entrer du texte ou un fichier.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Publier - Spinzone</title>
    <style>
        body {
            background: #121212;
            color: white;
            font-family: Arial, sans-serif;
            padding: 40px;
        }
        form {
            background: #1e1e1e;
            padding: 20px;
            border-radius: 12px;
            width: 400px;
            margin: auto;
        }
        textarea, input[type="file"] {
            width: 100%;
            margin-top: 10px;
            padding: 8px;
            border-radius: 6px;
            border: none;
        }
        button {
            background: #0055ff;
            color: white;
            border: none;
            padding: 10px;
            margin-top: 20px;
            width: 100%;
            border-radius: 6px;
            font-weight: bold;
        }
        .msg { margin-top: 10px; text-align: center; }
        .success { color: lightgreen; }
        .error { color: red; }
    </style>
</head>
<body>
    <form method="POST" enctype="multipart/form-data">
        <h2>Créer une publication</h2>
        <textarea name="content" rows="4" placeholder="Écrivez quelque chose..."></textarea>
        <input type="file" name="media" accept="image/*,video/*,audio/*">
        <button type="submit">Publier</button>
        <?php if ($success): ?><div class="msg success"><?= $success ?></div><?php endif; ?>
        <?php if ($error): ?><div class="msg error"><?= $error ?></div><?php endif; ?>
    </form>
</body>
</html>
