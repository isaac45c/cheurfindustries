<?php
// logger.php

function write_log(string $action, string $username = 'guest', ?string $logfile = null): void
{
    $defaultLogFile = __DIR__ . '/log.txt';
    $logfile = $logfile ?? $defaultLogFile;
    $maxLines = 100000;

    // Obtenir timestamp avec microsecondes
    $microtime = microtime(true);
    $datetime = DateTime::createFromFormat('U.u', number_format($microtime, 6, '.', ''));
    $timestamp = $datetime->format("Y-m-d H:i:s.u");

    // Adresse IP
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        $ip = $_SERVER['REMOTE_ADDR'];
    } else {
        $ip = 'unknown';
    }

    // Page visitée
    $page = $_SERVER['REQUEST_URI'] ?? 'unknown';

    // Nouvelle ligne de log
    $logLine = "[$timestamp] IP: $ip | User: $username | Page: $page | Action: $action" . PHP_EOL;

    // Gestion de la rotation du log
    if (file_exists($logfile)) {
        $lines = file($logfile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $lineCount = count($lines);

        if ($lineCount >= $maxLines) {
            $backupDir = dirname(__DIR__) . '/backup/log/';
            if (!is_dir($backupDir)) {
                mkdir($backupDir, 0777, true);
            }

            // Extraire date de la première et dernière ligne
            $firstDate = getLogDateFromLine($lines[0]);
            $lastDate = getLogDateFromLine($lines[$lineCount - 1]);

            // Numéro de backup = nombre de fichiers déjà présents
            $files = glob($backupDir . '*log*.txt');
            $index = count($files) + 1;

            // Format du nom : [index]log[date1]---[date2].txt
            $backupName = sprintf("%dlog%s---%s.txt", $index, $firstDate, $lastDate);
            $backupPath = $backupDir . $backupName;

            // Déplacer le fichier
            rename($logfile, $backupPath);
        }
    }

    // Ajouter la ligne au fichier
    file_put_contents($logfile, $logLine, FILE_APPEND | LOCK_EX);
}

/**
 * Extrait une date formatée depuis une ligne de log.
 * Exemple d’entrée : "[2025-05-22 14:30:01.123456] ..."
 * Retourne : "2025-05-22_14-30-01"
 */
function getLogDateFromLine(string $line): string
{
    if (preg_match('/\[(.*?)\]/', $line, $matches)) {
        $rawDate = $matches[1];
        $dateTime = DateTime::createFromFormat('Y-m-d H:i:s.u', $rawDate);
        return $dateTime ? $dateTime->format('Y-m-d_H-i-s') : 'unknown_date';
    }
    return 'unknown_date';
}
