<?php
include_once "create_user_pages.php";
$username_err = $email_err = $password_err = $success_msg = "";
$username = $email = $password = "";

// Charger les utilisateurs existants
$users = file_exists("users.json") ? json_decode(file_get_contents("users.json"), true) : [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    // Vérifications
    if (empty($username)) {
        $username_err = "Please enter a username.";
    } elseif (!ctype_alnum(str_replace(['@', '-', '_'], '', $username))) {
        $username_err = "Username can only contain letters, numbers, @, -, or _.";
    } else {
        foreach ($users as $user) {
            if ($user["username"] === $username) {
                $username_err = "Username already exists.";
                break;
            }
        }
    }

    if (empty($email)) {
        $email_err = "Please enter an email.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_err = "Invalid email format.";
    } else {
        foreach ($users as $user) {
            if ($user["email"] === $email) {
                $email_err = "Email already used.";
                break;
            }
        }
    }

    if (empty($password)) {
        $password_err = "Please enter a password.";
    } elseif (strlen($password) < 6) {
        $password_err = "Password must be at least 6 characters.";
    }

    if (!$username_err && !$email_err && !$password_err) {
        $new_user = [
            "username" => $username,
            "email" => $email,
            "password" => password_hash($password, PASSWORD_DEFAULT),
            "reg_date" => date("Y-m-d H:i:s"),
            "role" => "user"
        ];
        $users[] = $new_user;
        file_put_contents("users.json", json_encode($users, JSON_PRETTY_PRINT));
        create_user_pages($username);
        $success_msg = "Registration successful! You can now <a href='login.php'>log in</a>.";
        $username = $email = $password = ""; // Clear form
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Spinzone</title>
    <style>
        body {
            background: #121212;
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background: #1e1e1e;
            padding: 30px;
            border-radius: 12px;
            width: 320px;
            box-shadow: 0 0 10px rgba(0,0,0,0.5);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #0055ff;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: none;
            border-radius: 6px;
        }
        button {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background: #0055ff;
            border: none;
            border-radius: 6px;
            color: white;
            font-weight: bold;
        }
        .error { color: red; font-size: 0.9em; }
        .success { color: lightgreen; text-align: center; margin-top: 10px; }
    </style>
</head>
<body>
    <form method="post">
        <h2>Register</h2>

        <input type="text" name="username" placeholder="Username" value="<?= htmlspecialchars($username) ?>">
        <?php if ($username_err): ?><div class="error"><?= $username_err ?></div><?php endif; ?>

        <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($email) ?>">
        <?php if ($email_err): ?><div class="error"><?= $email_err ?></div><?php endif; ?>

        <input type="password" name="password" placeholder="Password">
        <?php if ($password_err): ?><div class="error"><?= $password_err ?></div><?php endif; ?>

        <button type="submit">Register</button>

        <?php if ($success_msg): ?><div class="success"><?= $success_msg ?></div><?php endif; ?>
                <a href="./login.php" style="color:#00f;text-decoration:underline;">login</a>
    </form>
</body>
</html>
