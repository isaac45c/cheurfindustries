<?php
function create_user_pages($username) {
    $baseDir = __DIR__ . '/../cont/';  // Retour au dossier "new ver"

    $publicPage = "<?php\n" .
        "echo '<h1>Profil de $username</h1>';\n" .
        "echo '<img src=\\'media/{$username}_banner.jpg\\' alt=\\'Bannière\\' style=\\'width:100%;height:auto;\\'>';\n" .
        "echo '<img src=\\'media/{$username}_avatar.jpg\\' alt=\\'Avatar\\' style=\\'width:150px;height:150px;border-radius:50%;\\'>';\n" .
        "?>";

    $accountPage = "<?php\nsession_start();\n" .
        "if (!isset(\$_SESSION['username']) || \$_SESSION['username'] !== '$username') {\n" .
        "header('Location: /index.php'); exit(); }\n" .
        "echo '<h1>Paramètres du compte de $username</h1>';\n?>";

    $analyticsPage = "<?php\nsession_start();\n" .
        "if (!isset(\$_SESSION['username']) || \$_SESSION['username'] !== '$username') {\n" .
        "header('Location: /index.php'); exit(); }\n" .
        "echo '<h1>Statistiques de $username</h1>';\n?>";

    file_put_contents($baseDir . "$username.php", $publicPage);

    if (!file_exists($baseDir . "$username")) {
        mkdir($baseDir . "$username", 0755, true);
    }

    file_put_contents($baseDir . "$username/account.php", $accountPage);
    file_put_contents($baseDir . "$username/analytics.php", $analyticsPage);
}
?>
