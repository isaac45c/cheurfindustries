// === SHARED HTML ===
const headerHTML = `
  <div>
    <nav>
      <h2>Spinzone</h2>
      <ul>
        <li id="nav-home" data-link="index.php" title="Home">Home</li>
        <li id="nav-trending" data-link="trending.php" title="Trending">Trending</li>
        <li id="nav-explore" data-link="explore.php" title="Explore">Explore</li>
        <li id="nav-library" data-link="library.php" title="Library">Library</li>
      </ul>
    </nav>
    <main>
      <header>
        <div class="search" role="search">
          <input id="search" placeholder="Search Spinzone..." aria-label="Search Spinzone" />
          <button id="searchBtn" aria-label="Search button">Search</button>
        </div>
        <div class="header-right" role="navigation" aria-label="User menu">
          <button id="publishBtn" type="button">Publish</button>
          <button id="settingsBtn" type="button" aria-haspopup="true" aria-expanded="false">Site Settings</button>
          <button id="accountBtn" type="button" aria-haspopup="true" aria-expanded="false">My Account</button>
        </div>

        <!-- Site Settings Popup -->
        <div class="popup" id="settingsPopup" role="dialog" aria-modal="true" aria-labelledby="settingsTitle" tabindex="-1">
          <h3 id="settingsTitle">Site Settings</h3>
          <button id="toggleThemePopup" type="button">Toggle Theme</button>
        </div>

        <!-- My Account Popup -->
        <div class="popup" id="accountPopup" role="dialog" aria-modal="true" aria-labelledby="accountTitle" tabindex="-1">
          <h3 id="accountTitle">My Account</h3>
          <button id="profileBtn" type="button">Profile</button>
          <button id="accountSettingsBtn" type="button">Account Settings</button>
          <button id="logoutBtn" type="button">Logout</button>
        </div>
      </header>
    </main>
  </div>
`;

const footerHTML = `
  <footer>
    &copy; 2025 Breach Place. All rights reserved.
  </footer>
`;

// === PAGE INITIALIZATION ===
document.addEventListener('DOMContentLoaded', () => {
  insertHeaderAndFooter();
});

// === INSERT SHARED ELEMENTS ===
function insertHeaderAndFooter() {
  const headerContainer = document.getElementById('header');
  const footerContainer = document.getElementById('footer');
  if (headerContainer) headerContainer.innerHTML = headerHTML;
  if (footerContainer) footerContainer.innerHTML = footerHTML;

  initInteractions();
  document.querySelectorAll('nav ul li').forEach(li => {
  li.addEventListener('click', () => {
    const target = li.getAttribute('data-link');
    if (target) {
      window.location.href = target;
    }
  });
});

}

// === INTERACTIONS ===
function initInteractions() {
  const isLoggedIn = window.isLoggedIn || false;
  const username = window.username || '';

  const accountBtn = document.getElementById('accountBtn');
  if (isLoggedIn) {
    accountBtn.textContent = `My Account (${username})`;
    accountBtn.onclick = () => {
      togglePopup('accountPopup', 'settingsPopup');
    };
  } else {
    accountBtn.textContent = "Log In";
    accountBtn.onclick = () => {
      window.location.href = 'serv/login.php';
    };
  }

  document.getElementById('publishBtn')?.addEventListener('click', () => {
    window.location.href = './serv/publish.php';
  });
  document.getElementById('profileBtn')?.addEventListener('click', () => {
  if (username) {
    window.location.href = `./cont/${username}.php`;
  }
});

document.getElementById('accountSettingsBtn')?.addEventListener('click', () => {
  if (username) {
    window.location.href = `./cont/${username}/account.php`;
  }
});

  document.getElementById('logoutBtn')?.addEventListener('click', () => {
    window.location.href = 'serv/logout.php';
  });

  document.getElementById('settingsBtn')?.addEventListener('click', () => {
    togglePopup('settingsPopup', 'accountPopup');
  });

  document.getElementById('toggleThemePopup')?.addEventListener('click', () => {
    document.body.classList.toggle('dark');
    document.body.classList.toggle('light');
    hidePopup('settingsPopup');
  });

  const pages = ['home', 'trending', 'explore', 'library'];
  pages.forEach(id => {
    document.getElementById('nav-' + id)?.addEventListener('click', () => {
      pages.forEach(i => {
        document.getElementById(i)?.classList.remove('active');
        document.getElementById('nav-' + i)?.classList.remove('active');
      });
      document.getElementById(id)?.classList.add('active');
      document.getElementById('nav-' + id)?.classList.add('active');
    });
  });

  document.addEventListener('click', e => {
    const settingsPopup = document.getElementById('settingsPopup');
    const accountPopup = document.getElementById('accountPopup');
    if (!document.getElementById('settingsBtn')?.contains(e.target) && !settingsPopup?.contains(e.target)) {
      hidePopup('settingsPopup');
    }
    if (!document.getElementById('accountBtn')?.contains(e.target) && !accountPopup?.contains(e.target)) {
      hidePopup('accountPopup');
    }
  });
}

function togglePopup(showId, hideId) {
  const showEl = document.getElementById(showId);
  const hideEl = document.getElementById(hideId);
  if (hideEl?.classList.contains('show')) {
    hideEl.classList.remove('show');
    document.getElementById(hideId.replace('Popup', 'Btn'))?.setAttribute('aria-expanded', false);
  }
  showEl?.classList.toggle('show');
  document.getElementById(showId.replace('Popup', 'Btn'))?.setAttribute('aria-expanded', showEl?.classList.contains('show'));
}

function hidePopup(id) {
  const el = document.getElementById(id);
  el?.classList.remove('show');
  document.getElementById(id.replace('Popup', 'Btn'))?.setAttribute('aria-expanded', false);
}
